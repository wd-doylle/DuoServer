import requests
import json
from bs4 import BeautifulSoup

headers = { 'Accept':'application/json, text/plain, */*',
		'Accept-Encoding':'gzip, deflate, sdch, br',
		'Accept-Language':'zh-CN,zh;q=0.8',
		'Connection':'keep-alive',
		'Cookie':'_T_WM=e6c87e2d385a294d5bd50b38dce06e8c; M_WEIBOCN_PARAMS=luicode%3D10000011%26lfid%3D1005056114898825%26fid%3D1005056114898825%26uicode%3D10000011',
		'Host':'m.weibo.cn',
		'Referer':'https://m.weibo.cn/u/6114898825/',
		'User-Agent':'Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/55.0.2883.87 Safari/537.36',
		'X-Requested-With':'XMLHttpRequest'}

end = False

for p in range(1):
	if end:
		break
	print('正在抓取第'+str(p)+'页....')
	url = 'https://m.weibo.cn/api/container/getIndex?containerid=1076035963683040&page=%d&count=50'%p
	r = requests.get(url,headers = headers)
	r.raise_for_status()
	data = json.loads(r.text,encoding = 'utf-8')
	# pprint(data,stream = open('pochan.txt','w',encoding = 'utf-8'))
	# open('pochan.json', 'w').write(r.text)

	print(len(data['data']['cards']))

	for c in data['data']['cards']:
		if c['card_type'] != 9 or 'retweeted_status' in c['mblog']:
			continue

		mblog = c['mblog']
		text = mblog['text']
		print(BeautifulSoup(text, 'html.parser').get_text())
	